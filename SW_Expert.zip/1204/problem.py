import sys
import checker
sys.stdin=open('input.txt','r')


##############################
##여기에 문제를 푸시면 됩니다.



##############################

if __name__=="__main__":
    checker.check()